﻿using ABB.Robotics.Controllers;
using ABB.Robotics.Controllers.Discovery;
using System;
using ABB.Robotics.Controllers.RapidDomain;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using ABB.Robotics.Controllers.Configuration;
using System.Diagnostics;
using ABB.Robotics;
using ABB.Robotics.Controllers.IOSystemDomain;
using System.Globalization;

namespace ControllerAPI
{
    public enum RapidState
    {
        Start,
        Stop
    }

    class CommunicationServer
    {
        static System.Diagnostics.Stopwatch LastMessageTimeout = new System.Diagnostics.Stopwatch();
        static TcpClient client;
        static NetworkStream stream;
        static Controller Robot = null;

        [MTAThread]
        static void Main(string[] args)
        {
            //variables for Unity communication
            client = START_COM_SERVER();
            Console.WriteLine("Connection established");
            stream = client.GetStream();

            LastMessageTimeout.Start();

            //Variables for RobotStudio comunnication
            ControllerInfo[] RobControllers = null;


            //variables for the program
            bool stop = false;
            bool RobotActive = false;
            string incommingMessage;
            string[] instruction;

            while (!stop)
            {
                incommingMessage = RECIEVE_MESSAGE();
                if (incommingMessage != null)
                {
                    LastMessageTimeout.Restart();
                    instruction = incommingMessage.Split('/');
                    switch (instruction[0])
                    {
                        case "MOVE":

                            break;
                        case "HOME":
                            MODIFY_RS_VAR("IHOME", "TRUE");
                            break;

                        case "NEW_HOME":

                            break;

                        case "SEND_PATH":
                            UPLOAD_PATH(instruction);
                            //Robot.Rapid.GetRapidData(new string[] { "T_ROB1", "Module1", "IMOVE" }).StringValue = "FALSE";
                            break;

                        case "CONNECT":
                            Robot = CONNECT_ROB(RobControllers, instruction[1]);
                            break;

                        case "SCAN":
                            RobControllers = SCAN_ROB_CONTROLERS();
                            string ControllersName = null;
                            foreach (var controler in RobControllers)
                            {
                                ControllersName += controler.Name;
                                ControllersName += " ";
                            }
                            SEND_MESSAGE(ControllersName);
                            break;

                        case "ACTIVATE_ROBOT":
                            RobotActive = true;
                            RobotState(RapidState.Start);
                            break;

                        case "DEACTIVATE_ROBOT":
                            RobotActive = false;
                            RobotState(RapidState.Stop);
                            break;

                        case "ROBOT_POS":
                            SEND_MESSAGE(ROBOT_POS_REQUEST());
                            break;
                        case "STOP":
                            stop = true;
                            break;

                        case "EMERGENCY_STOP":
                            MODIFY_RS_Signal("EmergencyStopRequest", true);

                            break;

                        case "EMERGENCY_ENDED":
                            MODIFY_RS_Signal("EmergencyStopRequest", false);
                            break;

                        case "CHECK":
                            string InReach = CHECK_REACHABILITY(instruction);
                            SEND_MESSAGE(InReach);
                            break;

                        default:
                            Console.WriteLine("Instruction not allowed, revice spealling");

                            break;
                    }

                }

            }
            client.Close();
            client.Dispose();
            Console.WriteLine("Press any key to terminate");
            Console.ReadKey();
        }


        static TcpClient START_COM_SERVER()
        {
            Console.WriteLine("Waiting for client to connect");
            TcpListener servidor = new TcpListener(System.Net.IPAddress.Loopback, 1100);
            servidor.Start();
            return servidor.AcceptTcpClient();
        }

        static async void SEND_MESSAGE(string message)
        {
            try
            {
                StreamWriter writer = new StreamWriter(stream);
                await writer.WriteLineAsync(message);
                writer.Flush();

            }
            catch (ObjectDisposedException e)
            {
                Console.WriteLine("ERROR:" + e.Message);

            }
            catch (SocketException e)
            {
                Console.WriteLine("ERROR:" + e.Message);
            }

        }

        static string RECIEVE_MESSAGE()
        {
            StreamReader sr = new StreamReader(stream);
            string message = null;
            if (stream.DataAvailable)
            {
                message = sr.ReadLine();
                if (message != "ROBOT_POS")
                {
                    Console.WriteLine(message);
                }

            }
            return message;
        }

        static Controller CONNECT_ROB(ControllerInfo[] ROBS, string selection)
        {
            if (ROBS == null || ROBS.Length == 0)
            {
                Console.WriteLine("Scann the network first");
                return null;
            }
            Controller robot;
            foreach (var item in ROBS)
            {
                if (item.Name == selection)
                {
                    try
                    {
                        robot = ABB.Robotics.Controllers.Controller.Connect(item, ConnectionType.Standalone);
                        UserInfo User = new UserInfo("Admin", "robotics");
                        robot.Logon(User);
                        //RobMaster = Mastership.Request(Robot);
                        return robot;
                    }
                    catch (System.InvalidOperationException e)
                    {
                        Console.WriteLine(e.Message);
                        return null;
                    }

                }
            }
            return null;
        }

        static private ControllerInfo[] SCAN_ROB_CONTROLERS()
        {
            NetworkScanner scanner = new NetworkScanner();
            scanner.Scan();
            foreach (ControllerInfo cont in scanner.Controllers)
            {
                Console.WriteLine($"{cont.Name}");
            }
            return scanner.GetControllers();
        }

        static private void UPLOAD_PATH(string[] points)
        {
            if (Robot == null)
            {
                Console.WriteLine("Robot controller not connected");
                return;
            }
            else if (points.Length > 50)
            {
                Console.WriteLine("More points than allowed. Reduce number of points or contact developers");
                return;
            }
            Mastership Master = null;
            try
            {
                Master = Mastership.Request(Robot);

                RapidData Positions = GET_RS_VARIABLE("Positions");
                RapidData ZoneValues = GET_RS_VARIABLE("PotitionZones");
                RapidData SpeedValues = GET_RS_VARIABLE("PotitionSpeeds");
                RapidData GripperActions = GET_RS_VARIABLE("GrippAction");
                RapidData MovementModes = GET_RS_VARIABLE("MovementMode");
                string[] data;
                GET_RS_VARIABLE("PosInPath").StringValue = "1";
                //MODIFY_RS_VAR("IPATH", "FALSE");
                for (int i = 1; i < points.Length; i++)
                {
                    data = points[i].Split('|');

                    IRapidData ZoneData = RS_ZONE_VALUE_CREATION(ZoneValues.ReadItem(i - 1), data[1]);
                    ZoneValues.WriteItem(ZoneData, i - 1);

                    IRapidData SpeedData = RS_SPEED_DATA_CREATION(SpeedValues.ReadItem(i - 1), data[2]);
                    SpeedValues.WriteItem(SpeedData, i - 1);

                    IRapidData GripAction = GripperActions.ReadItem(i - 1);
                    if (data[3] == "close")
                    {

                        MODIFY_RS_VAR(GripAction, "TRUE", Master);
                    }
                    else
                    {
                        MODIFY_RS_VAR(GripAction, "FALSE", Master);
                    }
                    GripperActions.WriteItem(GripAction, i - 1);

                    IRapidData MovementMode = MovementModes.ReadItem(i - 1);

                    if (data[4] == "Linear")
                    {
                        MODIFY_RS_VAR(MovementMode, "0", Master);
                    }
                    else if (data[4] == "Joint")
                    {
                        MODIFY_RS_VAR(MovementMode, "1", Master);
                    }
                    else if (data[4] == "Circular")
                    {
                        MODIFY_RS_VAR(MovementMode, "2", Master);
                    }

                    MovementModes.WriteItem(MovementMode, i - 1);


                    RobTarget Point = RS_POINT_CREATION(data[0], (RobTarget)Positions.ReadItem(i - 1), Master);
                    Positions.WriteItem(Point, i - 1);
                }

                for (int i = points.Length; i < 50 && ((RobTarget)Positions.ReadItem(i - 1)).ToString() != "[[0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,0,0]]"; i++)
                {
                    RobTarget Point = RS_POINT_CREATION("[[0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,0,0]]", (RobTarget)Positions.ReadItem(i - 1), Master);
                    Positions.WriteItem(Point, i - 1);
                }
                //MODIFY_RS_VAR("IPATH", "TRUE");
                Positions.Dispose();
                Master.Release();
                Master.Dispose();
            }
            catch (MasterRejectException e)
            {
                return;
            }
            catch
            {
                Master.Release();
                Master.Dispose();
            }

        }

        static void RobotState(RapidState state)
        {
            //Mastership Master = null;
            try
            {
                //Master = Mastership.Request(Robot);
                Robot.AuthenticationSystem.DemandGrant(Grant.ExecuteRapid);
                if (Robot.AuthenticationSystem.CheckDemandGrant(Grant.ExecuteRapid) == false)
                {
                    try
                    {
                        Robot.AuthenticationSystem.DemandGrant(Grant.ExecuteRapid);
                    }
                    catch (GrantDemandRejectedException e)
                    {
                        Debug.WriteLine(e.Message);
                    }
                }
                if (state == RapidState.Start)
                {
                    MODIFY_RS_VAR("IPATH", "TRUE");
                    //Robot.Rapid.GetRapidData(new string[] { "T_ROB1", "Module1", "IPATH" }).StringValue = "TRUE";
                    //Console.WriteLine(robot.Rapid.Start().ToString());
                }
                else if (state == RapidState.Stop)
                {
                    MODIFY_RS_VAR("IPATH", "False");
                    //Robot.Rapid.GetRapidData(new string[] { "T_ROB1", "Module1", "IPATH" }).StringValue = "FALSE";
                    //robot.Rapid.Stop();
                }
            }
            catch (UasRejectException e)
            {
                Debug.WriteLine(e.Message);
                //Master.Release();
                //Master.Dispose();
                return;
            }
            catch (MasterRejectException e)
            {
                return;
            }

            //Master.Release();
            //Master.Dispose();
        }

        static string CHECK_REACHABILITY(string[] points)
        {
            if (Robot == null)
            {
                Console.WriteLine("Robot controller not connected");
                return "NULL";
            }
            else if (points.Length > 50)
            {
                Console.WriteLine("More points than allowed. Reduce number of points or contact developers");
                return "NULL";
            }
            Mastership Master = null;
            try
            {
                Master = Mastership.Request(Robot);

                RapidData ReachCheckList = GET_RS_VARIABLE("ReachCheck");

                string[] data;
                GET_RS_VARIABLE("PosInPath").StringValue = "1";
                for (int i = 1; i < points.Length; i++)
                {
                    data = points[i].Split('|');
                    RobTarget Point = RS_POINT_CREATION(data[0], (RobTarget)ReachCheckList.ReadItem(i - 1), Master);
                    ReachCheckList.WriteItem(Point, i - 1);

                }

                for (int i = points.Length; i < 50 && ((RobTarget)ReachCheckList.ReadItem(i - 1)).ToString() != "[[0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,0,0]]"; i++)
                {
                    RobTarget Point = RS_POINT_CREATION("[[0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,0,0]]", (RobTarget)ReachCheckList.ReadItem(i - 1), Master);
                    ReachCheckList.WriteItem(Point, i - 1);
                }
                MODIFY_RS_VAR("IREACHCHECK", "TRUE");
                ReachCheckList.Dispose();
                Master.Release();
                Master.Dispose();
            }
            catch (MasterRejectException e)
            {
                return "NULL";
            }
            catch
            {
                Master.Release();
                Master.Dispose();
                return "NULL";
            }

            while (GET_RS_VARIABLE("CHECKDONE").StringValue == "FALSE") ;
            RapidData Result = GET_RS_VARIABLE("OREACH");

            string message = Result.StringValue.Trim('[', ']');
            MODIFY_RS_VAR("CHECKDONE", "FALSE");
            MODIFY_RS_VAR("IREACHCHECK", "FALSE");

            MODIFY_RS_VAR("PosInPath", "1");

            return message;

        }

        static RobTarget RS_POINT_CREATION(string point, RobTarget RSpoint, Mastership Master)
        {
            string[] separateInfo = point.Split('_');                                           //Separa en posicion y rotación
            string[] position = separateInfo[0].Split(',');                                     //separo cada número de la posicion
            string[] orientation = separateInfo[1].Split(',');                                  //separo cada número de la rotacion
            double[] orientationNum = { 0, 0, 0 };
            double[] positionNum = { 0, 0, 0 };

            orientationNum[0] = double.Parse(orientation[0], new System.Globalization.CultureInfo("en-US")) * -1;
            orientationNum[1] = double.Parse(orientation[2], new System.Globalization.CultureInfo("en-US")) * -1;
            orientationNum[2] = double.Parse(orientation[1], new System.Globalization.CultureInfo("en-US")) * -1;

            positionNum[0] = float.Parse(position[0], new System.Globalization.CultureInfo("en-US")) * -1;
            positionNum[1] = float.Parse(position[2], new System.Globalization.CultureInfo("en-US")) * -1;
            positionNum[2] = float.Parse(position[1], new System.Globalization.CultureInfo("en-US"));

            try
            {
                if (Master == null)
                {
                    Master = Mastership.Request(Robot);
                }
                separateInfo[0] = positionNum[0].ToString("F4", new CultureInfo("en-US")) + ", " + positionNum[1].ToString("F4", new CultureInfo("en-US")) + ", " + positionNum[2].ToString("F4", new CultureInfo("en-US"));
                RSpoint.Trans.FillFromString2("[" + separateInfo[0] + "]");
                RSpoint.Rot.FillFromEulerAngles(orientationNum[0], orientationNum[1], orientationNum[2]);
                RSpoint.Robconf.FillFromString2("[0,0,0,0]");
                RSpoint.Extax.FillFromString2("[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]");
            }
            catch
            {
                if (Master.IsMaster)
                {
                    Master.Release();
                    Master.Dispose();
                }
            }

            return RSpoint;
        }
        static IRapidData RS_ZONE_VALUE_CREATION(IRapidData RSpoint, string value)
        {
            int numValue = int.Parse(value, new System.Globalization.CultureInfo("en-US"));

            string aux = "[FALSE,";
            switch (numValue)
            {
                case 0:
                    aux += "0.3,0.3,0.3,0.15,0.3,0.15";
                    break;
                case 1:
                    aux += "1,1,1,0.5,1,0.5";
                    break;
                case 5:
                    aux += "5,8,8,4,8,4";
                    break;
                default:
                    aux += "10,15,15,7.5,15,7.5";
                    break;
            }
            aux += "]";
            RSpoint.FillFromString(aux);
            return RSpoint;
        }
        static IRapidData RS_SPEED_DATA_CREATION(IRapidData RSpoint, string value)
        {
            RSpoint.FillFromString("[" + value + ",1000,500,1000]");
            return RSpoint;
        }

        static RapidData GET_RS_VARIABLE(string variable)
        {
            return Robot.Rapid.GetRapidData(new string[] { "T_ROB1", "Module1", variable });
        }
        static void MODIFY_RS_VAR(string variable, string value)
        {
            Mastership Master = null;
            try
            {
                Master = Mastership.Request(Robot);
                GET_RS_VARIABLE(variable).StringValue = value;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Master.Release();
                Master.Dispose();
                return;
            }

            Master.Release();
            Master.Dispose();
        }
        static void MODIFY_RS_VAR(IRapidData variable, string value, Mastership Master)
        {
            try
            {
                if (!Master.IsMaster || Master == null)
                {
                    Master = Mastership.Request(Robot);
                }
                variable.FillFromString(value);
            }
            catch (MasterRejectException e)
            {
                return;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Master.Release();
                Master.Dispose();
                return;
            }
        }

        static void MODIFY_RS_Signal(string signal, bool value)
        {
            Mastership Master = null;
            try
            {
                Master = Mastership.Request(Robot);
                DigitalSignal diSig = (DigitalSignal)Robot.IOSystem.GetSignal(signal); ;
                if (value)
                {
                    diSig.Set();
                }
                else
                {
                    diSig.Reset();
                }

                diSig.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Master.Release();
                Master.Dispose();
                return;
            }

            Master.Release();
            Master.Dispose();
        }

        static string ROBOT_POS_REQUEST()
        {
            string message = Robot.MotionSystem.ActiveMechanicalUnit.GetPosition().ToString();
            message += "/" + Robot.IOSystem.GetSignal("Asi1LedRed").Value.ToString() + "," + Robot.IOSystem.GetSignal("Asi1LedGreen").Value.ToString() + "," + Robot.IOSystem.GetSignal("Asi1LedBlue").Value.ToString();

            return message;
        }
    }
}

